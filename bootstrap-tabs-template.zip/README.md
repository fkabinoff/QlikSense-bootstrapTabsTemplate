QlikSense-BootstrapTabsTemplate
================

This template for Qlik Sense 2.x includes tab navigation and Bootstrap.

*********************************
Installation & Use
*********************************
Qlik Sense Desktop - Simply take this folder and add it to C:\Users\[YOUR USER NAME]\Documents\Qlik\Sense\Extensions\Templates.
Once you do this you should see the new template appear in the dropdown list after clicking the "Create New" button in the dev hub.